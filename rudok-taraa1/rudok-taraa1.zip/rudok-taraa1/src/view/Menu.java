package view;

import javax.swing.*;
import java.awt.event.KeyEvent;

public class Menu extends JMenuBar {

    private JMenuItem rename;

    public Menu(){
        JMenu fajl = new JMenu("File");
        JMenuItem novo = new JMenuItem("New");

        novo.addActionListener(MainFrame.getInstance().getAm().getNova());

        JMenuItem delete = new JMenuItem("Delete");
        rename = new JMenuItem("Rename");
        rename.addActionListener(MainFrame.getInstance().getAm().getRename());

        delete.addActionListener(MainFrame.getInstance().getAm().getDelete());


        JMenu help = new JMenu("Help");
        JMenuItem edit = new JMenuItem("Edit");



        MainFrame.getInstance();
        fajl.add(novo);
        fajl.add(rename);
        fajl.add(delete);
        help.add(edit);
        add(fajl);
        add(help);
    }

    public JMenuItem getRename() {
        return rename;
    }
}
