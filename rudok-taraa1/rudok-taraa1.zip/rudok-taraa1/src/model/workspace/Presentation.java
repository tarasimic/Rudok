package model.workspace;

import model.node.RuNode;
import model.node.RuNode_Composite;


import java.util.ArrayList;

public class Presentation extends RuNode_Composite {

    private ArrayList<Slide> slajdovi;


    public Presentation(String ime, RuNode parent) {
        super(ime, parent);
        slajdovi = new ArrayList<>();
    }

    @Override
    public void addChild(RuNode rn) {
        if(rn instanceof Slide){
            Slide slajd = (Slide) rn;
            if(!this.getDeca().contains(slajd)){
                this.getDeca().add(slajd);
                notifySubscriber(slajd, "dodavanje");
            }
        }
    }

    @Override
    public void removeChild(RuNode rn) {
        if(rn instanceof Slide){
            Slide s = (Slide) rn;
            if(this.getDeca().contains(s)){
                this.getDeca().remove(s);
                notifySubscriber(s, "uklanjanje");
            }
        }
    }



}