package view;

import controller.action.InfoAction;

import javax.swing.*;

public class Toolbar extends JToolBar {
    private JButton jb;
    private JButton info;
    private JButton rename;
    private JButton delete;

    public Toolbar(){
        jb = new JButton();
        jb.setToolTipText("New");
        jb.setIcon(new ImageIcon("images/new-document.png"));
        jb.setFocusable(true);
        jb.addActionListener(MainFrame.getInstance().getAm().getNova());
        add(jb);

        addSeparator();

        info = new JButton();
        info.setToolTipText("Info");
        info.setIcon(new ImageIcon("images/info.png"));
        info.setFocusable(true);
        info.addActionListener(MainFrame.getInstance().getAm().getIa());

        add(info);

        rename = new JButton();
        rename.setToolTipText("Rename");
        rename.setIcon(new ImageIcon("images/edit.png"));
        rename.setFocusable(true);
        rename.addActionListener(MainFrame.getInstance().getAm().getRename());
        addSeparator();
        add(rename);

        delete = new JButton();
        delete.setToolTipText("Delete");
        delete.setIcon(new ImageIcon("images/bin.png"));
        delete.setFocusable(true);
        delete.addActionListener(MainFrame.getInstance().getAm().getDelete());
        addSeparator();
        add(delete);
    }

    public JButton getJb() {
        return jb;
    }

    public void setJb(JButton jb) {
        this.jb = jb;
    }

    public JButton getInfo() {
        return info;
    }

    public void setInfo(JButton info) {
        this.info = info;
    }
}

