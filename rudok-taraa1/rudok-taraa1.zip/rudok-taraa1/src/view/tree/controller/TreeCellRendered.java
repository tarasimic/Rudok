package view.tree.controller;

import javax.swing.tree.DefaultTreeCellRenderer;

public class TreeCellRendered extends DefaultTreeCellRenderer {
}
