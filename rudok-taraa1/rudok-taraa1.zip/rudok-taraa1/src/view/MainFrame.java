package view;



import controller.action.ActionManager;
import model.workspace.Workspace;
import view.tree.model.TreeNodeImplementation;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private static MainFrame instance = null;
    Menu menu;
    Toolbar tb;
    private JTree tree;
    private TreeNodeImplementation tn;
    private JDesktopPane right;

    private ActionManager am;

    private MainFrame(){

    }

    public TreeNodeImplementation getTn() {
        return tn;
    }

    public ActionManager getAm() {
        return am;
    }

    private void inicijalizacija(){
        am = new ActionManager();
        tn = new TreeNodeImplementation();
        this.tree = tn.generate(new Workspace("Workspace"));
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension size = tk.getScreenSize();
        int duzina = size.height;
        int sirina = size.width;
        setSize(sirina / 2, duzina / 2);
        setTitle("Rudok");
        menu = new Menu();
        setJMenuBar(menu);
        tb = new Toolbar();

        JPanel left = new JPanel();
        left.setPreferredSize(new Dimension(300, 300));
        left.setLayout(new BoxLayout(left, 1));
        JScrollPane skrol = new JScrollPane(this.tree);
        skrol.setMinimumSize(new Dimension(100,100));
        skrol.setVerticalScrollBarPolicy(20);

        left.add(skrol);

        add(left, BorderLayout.WEST);





         right = new JDesktopPane();

        add(right, BorderLayout.EAST);

        JSplitPane sp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, right);
        add(sp);

        add(tb, BorderLayout.NORTH);


    }

    public Menu getMenu(){
        return menu;
    }

    public Toolbar getTb(){
        return tb;
    }

    public JDesktopPane getRight() {
        return right;
    }

    public static MainFrame getInstance(){
        if(instance == null){
            instance = new MainFrame();
            instance.inicijalizacija();
        }
        return instance;
    }

    public JTree getTree() {
        return tree;
    }
}
