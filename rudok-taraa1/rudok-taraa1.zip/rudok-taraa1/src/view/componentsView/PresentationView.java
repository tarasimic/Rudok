package view.componentsView;

import model.node.RuNode_Composite;
import observer.ISubscriber;

import javax.swing.*;

public class PresentationView extends JInternalFrame implements ISubscriber {

    private RuNode_Composite prezentacija;
    private JTabbedPane jtab;

    public PresentationView(RuNode_Composite prezentacija){
        super("", true, true, true, true);

    }



    public RuNode_Composite getPrezentacija() {
        return prezentacija;
    }

    public JTabbedPane getJtab() {
        return jtab;
    }

    @Override
    public void update(Object notification, String akcija) {

    }
}
