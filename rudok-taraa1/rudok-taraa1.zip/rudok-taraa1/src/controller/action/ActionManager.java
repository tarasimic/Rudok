package controller.action;

import javax.swing.*;

public  class ActionManager {

    private InfoAction ia;
    private AddAction nova;
    private RenameAction rename;
    private DeleteNodeAction delete;

    public ActionManager(){
        ia = new InfoAction();
        nova = new AddAction();
        rename = new RenameAction();
        delete = new DeleteNodeAction();
    }

    public AddAction getNova() {
        return nova;
    }

    public InfoAction getIa() {
        return ia;
    }

    public RenameAction getRename() {
        return rename;
    }

    public DeleteNodeAction getDelete() {
        return delete;
    }
}
