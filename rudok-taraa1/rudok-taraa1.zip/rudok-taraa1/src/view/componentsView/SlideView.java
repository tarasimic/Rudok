package view.componentsView;

import observer.ISubscriber;

public class SlideView implements ISubscriber {


    @Override
    public void update(Object notification, String akcija) {

    }
}
