package observer;

public interface ISubscriber {

    void update(Object notification, String string);
}
