package view.componentsView;

import com.sun.tools.javac.Main;
import model.node.RuNode_Composite;
import model.workspace.Project;
import observer.ISubscriber;
import view.MainFrame;
import view.tree.model.MyTreeNode;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class ProjectView extends JInternalFrame implements ISubscriber {


    private RuNode_Composite project;
    private JTabbedPane tabbedPane;
    private ArrayList<PresentationView> prezentacija;

    public ProjectView(RuNode_Composite project){
        super("", true, true, true, true);
        this.project = project;
        this.project.addSubscriber(this);
        this.setSize(400, 400);
        this.tabbedPane = new JTabbedPane();
        this.setTitle(project.getIme());
        this.add(tabbedPane);
        this.setVisible(true);
    }

    @Override
    public void update(Object notification, String akcija) {
        if(akcija == "dodavanje"){
            this.add(tabbedPane);
            this.tabbedPane.removeAll();
        }
        if(akcija == "rename"){
            System.out.println("uso");
            JTree tree = MainFrame.getInstance().getTree();
            MyTreeNode putanja = (MyTreeNode) MainFrame.getInstance().getTree().getLastSelectedPathComponent();
            for(Component komponenta : MainFrame.getInstance().getRight().getComponents()) {
                if(((ProjectView)komponenta).equals(this)){
                    System.out.println("uso i ovde mentolu");
                    ((ProjectView)komponenta).setTitle(this.project.getIme());
                    System.out.println(this.project.getIme());
                }
            }
        }
    }



    public JTabbedPane getTabbedPane() {
        return tabbedPane;
    }

    public void setTabbedPane(JTabbedPane tabbedPane) {
        this.tabbedPane = tabbedPane;
    }



    public RuNode_Composite getProject() {
        return project;
    }
}
