package app;

import view.MainFrame;

public class Application {

    public static void main(String[] args) {
        MainFrame mf = MainFrame.getInstance();
        mf.setLocationRelativeTo(null);
        mf.setVisible(true);
    }

}
