package controller.action;

import model.node.RuNode_Composite;
import model.workspace.Presentation;
import model.workspace.Project;
import model.workspace.Workspace;
import view.MainFrame;
import view.tree.model.MyTreeNode;
import view.tree.view.MyTree;

import javax.swing.*;
import javax.swing.tree.TreePath;
import java.awt.event.ActionEvent;

public class DeleteNodeAction extends AbstractAction {


    @Override
    public void actionPerformed(ActionEvent e) {
        MyTree jt = (MyTree)MainFrame.getInstance().getTree();
        MyTreeNode treeNode = (MyTreeNode) MainFrame.getInstance().getTree().getLastSelectedPathComponent();

        Object selektovani = null;
        if (!(treeNode.getR() instanceof Workspace)) {
           selektovani  = ((MyTreeNode)((MyTreeNode) MainFrame.getInstance().getTree().getLastSelectedPathComponent()).getParent()).getR();
        }

        if ((treeNode.getR() instanceof Workspace)) {
            ((Workspace)(RuNode_Composite) treeNode.getR()).getDeca().clear();
        }

        else if (treeNode.getR() instanceof Project) {
            System.out.println("instanca");
            ((Workspace)(RuNode_Composite)selektovani).removeChild((Project)treeNode.getR());
        }

        else if (treeNode.getR() instanceof Presentation) {
            ((Project)selektovani).removeChild((Presentation)treeNode.getR());
        }
        System.out.println(jt);
        SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getTree());
    }
}
